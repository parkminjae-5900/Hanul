# 서진우 웹명함 GitHub Pages 업로드 방법

1. GitHub 저장소 `parkminjae-5900.github.io` 접속
2. `Add file` → `Create new file`
3. 파일명에 `seojinwoo/index.html` 입력 후 index.html 내용 붙여넣기
4. 같은 방식으로 `seojinwoo/preview.png`, `seojinwoo/portrait.png` 업로드
5. 업로드 후 주소 사용

주소:
https://parkminjae-5900.github.io/seojinwoo/

문자 발송 예시:
서진우 수석장례지도사
https://parkminjae-5900.github.io/seojinwoo/

주의:
문자 미리보기는 카카오톡/문자앱/통신사에 따라 바로 안 뜨고 몇 분 뒤 반영될 수 있습니다.
